package com.group8.fatigue_test.models;

public @ Test {
    
}
