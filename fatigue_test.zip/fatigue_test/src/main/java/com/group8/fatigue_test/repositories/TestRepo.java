package com.group8.fatigue_test.repositories;

public class TestRepo {
    
}
