package com.group8.fatigue_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FatigueTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
